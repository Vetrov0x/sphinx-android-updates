#!/usr/bin/python3
"""Opt-in Telegram-only SSH reserve. No routes, VPN or system proxy changes.

Events are sanitized: SOCKS port, EXPIRES seconds, READY HTTP-port, PAC base64,
ERROR fixed-code, ROUTE_DOWN. Readiness requires TLS payload AND MTProto nonce.
Only this process's SSH child/listeners are stopped. EOF on stdin stops the reserve.
"""
import argparse
import base64
import hashlib
import http.client
import importlib.util
import ipaddress
import json
import os
from pathlib import Path
import signal
import socket
import ssl
import stat
import struct
import subprocess
import sys
import threading
import time

_spec = importlib.util.spec_from_file_location("sphinx_core", Path(__file__).with_name("sphinx_core.py"))
core = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(core)

HOST = "2.29.62.196"
USER = "sphinx-aiur-telegram"
DEFAULT_PROFILE = Path.home() / ".local/share/sphinx-hel-probe/mac-telegram-reserve-20261118/profile.json"
HEALTH_HOST = "deb.debian.org"
HEALTH_PATH = "/debian/README"
HEALTH_SIZE = 1198
HEALTH_SHA256 = "a0c66a1fe046f008b6db9584d05347dd8ded2b78250851b61d3861c213ac361e"
DC = "149.154.167.50"
NETWORKS = tuple(ipaddress.ip_network(n) for n in (
    "91.108.56.0/22", "91.108.4.0/22", "91.108.8.0/22", "91.108.16.0/22",
    "91.108.12.0/22", "149.154.160.0/20", "91.105.192.0/23", "91.108.20.0/22",
    "185.76.151.0/24", "2001:b28:f23d::/48", "2001:b28:f23f::/48",
    "2001:67c:4e8::/48", "2001:b28:f23c::/48", "2a0a:f280::/32"))


class ReserveError(ValueError):
    pass


def _private_file(path, root, secret=True):
    p = Path(path)
    try:
        if any(ord(ch) < 32 or ord(ch) == 127 or ch == "%" for ch in str(p)):
            raise ReserveError("PROFILE_INVALID")
        if not p.is_absolute() or p.resolve() != p or p.parent != root:
            raise ReserveError("PROFILE_INVALID")
        s = p.lstat()
        forbidden = 0o077 if secret else 0o022
        if not stat.S_ISREG(s.st_mode) or s.st_uid != os.getuid() or stat.S_IMODE(s.st_mode) & forbidden:
            raise ReserveError("PROFILE_INVALID")
        if s.st_size == 0 or s.st_size > 16384:
            raise ReserveError("PROFILE_INVALID")
    except (OSError, TypeError):
        raise ReserveError("PROFILE_INVALID")
    return str(p)


def load_profile(path=DEFAULT_PROFILE, now=None):
    path = Path(path).expanduser()
    root = path.parent.resolve()
    try:
        directory = root.stat()
        if directory.st_uid != os.getuid() or stat.S_IMODE(directory.st_mode) & 0o022:
            raise ReserveError("PROFILE_INVALID")
        _private_file(path, root)
        p = json.loads(path.read_text("utf-8"))
        if set(p) != {"version", "host", "port", "user", "identityFile", "knownHostsFile", "expiresAt"}:
            raise ReserveError("PROFILE_INVALID")
        if type(p["version"]) is not int or p["version"] != 1 or p["host"] != HOST or p["user"] != USER:
            raise ReserveError("PROFILE_INVALID")
        if type(p["port"]) is not int or p["port"] != 22:
            raise ReserveError("PROFILE_INVALID")
        expiry = p["expiresAt"]
        if type(expiry) not in (int, float):
            raise ReserveError("PROFILE_INVALID")
        if expiry > 10**12:
            expiry /= 1000
        now = time.time() if now is None else now
        if not now < expiry <= now + 86400:
            raise ReserveError("ACCESS_EXPIRED" if expiry <= now else "PROFILE_INVALID")
        p["expiresAt"] = expiry
        p["identityFile"] = _private_file(p["identityFile"], root)
        p["knownHostsFile"] = _private_file(p["knownHostsFile"], root, secret=False)
        # No wildcard, marker or hashed aliases: this isolated pin names exactly this server.
        lines = [line.split() for line in Path(p["knownHostsFile"]).read_text("ascii").splitlines()
                 if line.strip() and not line.lstrip().startswith("#")]
        if not lines or any(len(x) != 3 or x[0] not in (HOST, "[%s]:22" % HOST)
                            or x[1] not in ("ssh-ed25519", "ecdsa-sha2-nistp256", "ssh-rsa") for x in lines):
            raise ReserveError("PIN_INVALID")
        for line in lines:
            if len(base64.b64decode(line[2], validate=True)) < 32:
                raise ReserveError("PIN_INVALID")
        return p
    except ReserveError:
        raise
    except (OSError, ValueError, TypeError, UnicodeError):
        raise ReserveError("PROFILE_INVALID")


def allowed(host, port):
    if type(port) is not int:
        return False
    if (host, port) in ((HEALTH_HOST, 443), ("web.telegram.org", 443), ("9.9.9.9", 53)):
        return True
    if port not in (80, 443, 5222):
        return False
    try:
        ip = ipaddress.ip_address(host)
        return str(ip) == host and any(ip in n for n in NETWORKS if n.version == ip.version)
    except ValueError:
        return False


def ssh_command(p, port):
    # Fixed ProxyCommand contains no profile-controlled shell text. -F excludes user SSH config.
    quoted = p["knownHostsFile"].replace("\\", "\\\\").replace('"', '\\"')
    return ["/usr/bin/ssh", "-F", "/dev/null", "-N", "-T", "-a", "-x",
            "-D", "127.0.0.1:%d" % port, "-i", p["identityFile"], "-p", "22",
            "-o", "BatchMode=yes", "-o", "IdentitiesOnly=yes", "-o", "IdentityAgent=none",
            "-o", "ExitOnForwardFailure=yes", "-o", "StrictHostKeyChecking=yes",
            "-o", 'UserKnownHostsFile="%s"' % quoted, "-o", "GlobalKnownHostsFile=/dev/null",
            "-o", "UpdateHostKeys=no", "-o", "ForwardAgent=no", "-o", "ForwardX11=no",
            "-o", "PermitLocalCommand=no", "-o", "ControlMaster=no", "-o", "ControlPath=none",
            "-o", "ConnectTimeout=15", "-o", "ServerAliveInterval=10", "-o", "ServerAliveCountMax=2",
            "-o", "LogLevel=ERROR", "-o", "ProxyCommand=/usr/bin/nc -b en0 %s 22" % HOST,
            "%s@%s" % (USER, HOST)]


def fixture_check(port, connect=core.socks5_connect, context=None):
    raw = connect(port, HEALTH_HOST, 443)
    raw.settimeout(15)
    with (context or ssl.create_default_context()).wrap_socket(raw, server_hostname=HEALTH_HOST) as s:
        s.sendall(("GET %s HTTP/1.1\r\nHost: %s\r\nConnection: close\r\nAccept-Encoding: identity\r\n\r\n"
                   % (HEALTH_PATH, HEALTH_HOST)).encode("ascii"))
        response = http.client.HTTPResponse(s)
        response.begin()
        body = response.read(HEALTH_SIZE + 1)
        if response.status != 200 or len(body) != HEALTH_SIZE or hashlib.sha256(body).hexdigest() != HEALTH_SHA256:
            raise ReserveError("PAYLOAD_FAILED")


def mtproto_check(port, connect=core.socks5_connect):
    nonce = os.urandom(16)
    request = struct.pack("<I", 0xbe7e8ef1) + nonce  # req_pq_multi, unauthenticated transport only
    packet = b"\0" * 8 + struct.pack("<Q", int(time.time() * 2**32) & ~3) + struct.pack("<I", len(request)) + request
    with connect(port, DC, 443) as s:
        s.settimeout(15)
        s.sendall(b"\xef" + bytes([len(packet) // 4]) + packet)
        first = core._recv_exact(s, 1)[0]
        words = int.from_bytes(core._recv_exact(s, 3), "little") if first == 127 else first
        if words < 16 or words > 1024:
            raise ReserveError("MTPROTO_FAILED")
        reply = core._recv_exact(s, words * 4)
        if reply[:8] != b"\0" * 8 or len(reply) < 56:
            raise ReserveError("MTPROTO_FAILED")
        length = struct.unpack("<I", reply[16:20])[0]
        if length != len(reply) - 20 or reply[20:24] != struct.pack("<I", 0x05162463) or reply[24:40] != nonce:
            raise ReserveError("MTPROTO_FAILED")


def check_payload(port):
    fixture_check(port)
    mtproto_check(port)


def ssh_failure(stderr):
    text = stderr.lower()
    if b"host key verification failed" in text or b"remote host identification has changed" in text:
        return "PIN_INVALID"
    if any(x in text for x in (b"network is unreachable", b"no route to host", b"can't assign requested address")):
        return "DIRECT_NETWORK_UNAVAILABLE"
    return "SSH_FAILED"


class Gateway(core.Adapter):
    """Public loopback SOCKS endpoint; denied destinations never reach SSH."""
    def __init__(self, upstream):
        super().__init__(0, upstream, ())
        self.clients = set()
        self.lock = threading.Lock()

    def _handle(self, c):
        up = None
        with self.lock:
            self.clients.add(c)
        try:
            c.settimeout(10)
            version, count = core._recv_exact(c, 2)
            methods = core._recv_exact(c, count)
            if version != 5 or count == 0 or 0 not in methods:
                c.sendall(b"\x05\xff"); return
            c.sendall(b"\x05\x00")
            version, command, reserved, typ = core._recv_exact(c, 4)
            if version != 5 or command != 1 or reserved != 0:
                return
            if typ == 1:
                host = str(ipaddress.ip_address(core._recv_exact(c, 4)))
            elif typ == 4:
                host = str(ipaddress.ip_address(core._recv_exact(c, 16)))
            elif typ == 3:
                host = core._recv_exact(c, core._recv_exact(c, 1)[0]).decode("ascii")
            else:
                return
            port = int.from_bytes(core._recv_exact(c, 2), "big")
            if self.closed or not allowed(host, port):
                c.sendall(b"\x05\x02\x00\x01" + b"\0" * 6); return
            up = core.socks5_connect(self.socks_port, host, port)
            with self.lock:
                self.clients.add(up)
            c.sendall(b"\x05\x00\x00\x01" + b"\0" * 6)
            c.settimeout(None)
            core._relay(c, up)
        except (OSError, ValueError, IndexError):
            pass
        finally:
            with self.lock:
                for s in (c, up):
                    if s is not None:
                        self.clients.discard(s)
                        s.close()
            self.sem.release()

    def close(self):
        super().close()
        with self.lock:
            for s in self.clients:
                try:
                    s.shutdown(socket.SHUT_RDWR)
                except OSError:
                    pass


class TelegramWebAdapter(core.Adapter):
    """Fail-closed HTTP proxy for the isolated browser, including Telegram DC IPs."""
    def _handle(self, c):
        upstream = None
        try:
            c.settimeout(10)
            request = b""
            while b"\r\n\r\n" not in request:
                data = c.recv(1024)
                if not data:
                    return
                request += data
                if len(request) > 8192:
                    return core._reply(c, 431, "Too Large")
            line = request.split(b"\r\n", 1)[0].decode("ascii")
            parts = line.split(" ")
            if len(parts) != 3 or parts[0] != "CONNECT" or not parts[1].endswith(":443"):
                return core._reply(c, 403, "Forbidden")
            host = parts[1][:-4]
            if host.startswith("[") and host.endswith("]"):
                host = host[1:-1]
            # Health/DNS are operator checks, not browser destinations.
            if self.closed or host == HEALTH_HOST or not allowed(host, 443):
                return core._reply(c, 403, "Forbidden")
            upstream = core.socks5_connect(self.socks_port, host, 443)
            c.sendall(b"HTTP/1.1 200 Connection Established\r\n\r\n")
            rest = request.split(b"\r\n\r\n", 1)[1]
            if rest:
                upstream.sendall(rest)
            c.settimeout(None)
            core._relay(c, upstream)
        except (OSError, ValueError, UnicodeError):
            pass
        finally:
            for s in (c, upstream):
                if s is not None:
                    s.close()
            self.sem.release()


def web_pac(port):
    # No DIRECT fallback for Telegram assets, WebSockets, redirects or a stopped reserve.
    return 'function FindProxyForURL(url, host) { return "PROXY 127.0.0.1:%d"; }' % port


PAYLOAD_DEADLINE = 40  # absolute seconds per probe: covers 10s connect + 15s socket timeouts
PROBE_INTERVAL = 60


class _Probe(object):
    """One payload check in a daemon worker so stop/expiry never wait on blocked I/O.

    The worker's sockets go through the owned Gateway; closing it (run's finally)
    shuts them down, so a cancelled or overdue worker unblocks and exits.
    """
    def __init__(self, payload, port, clock=time.monotonic):
        self.done = threading.Event()
        self.error = None
        self.completed_at = None
        self.clock = clock
        self.deadline = clock() + PAYLOAD_DEADLINE
        def work():
            try:
                payload(port)
            except Exception as e:
                self.error = e
            finally:
                self.completed_at = clock()  # stamped in the worker, before done is visible
                self.done.set()
        threading.Thread(target=work, daemon=True).start()

    def finished(self):
        """True only if passed by the deadline; re-raises payload failure; else PAYLOAD_FAILED.

        Judged on when the worker completed, not when it is polled: late completion
        fails closed, on-time completion polled late still passes.
        """
        if self.done.is_set():
            if self.error is not None:
                raise self.error
            if self.completed_at is None or self.completed_at > self.deadline:
                raise ReserveError("PAYLOAD_FAILED")
            return True
        if self.clock() > self.deadline:
            raise ReserveError("PAYLOAD_FAILED")
        return False


def run(profile, stop, emit=core.emit, spawn=subprocess.Popen, payload=check_payload):
    ssh = gateway = adapter = None
    stderr_tail = bytearray()
    expiry_cancelled = threading.Event()
    expired = threading.Event()
    try:
        p = load_profile(profile)
        upstream = core.free_loopback_port()
        ssh = spawn(ssh_command(p, upstream), stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                    stderr=subprocess.PIPE, close_fds=True)
        def expire_transport():
            if expiry_cancelled.wait(max(0, p["expiresAt"] - time.time())):
                return
            expired.set()
            stop.set()
            for server in (adapter, gateway):
                if server:
                    server.close()
            if ssh.poll() is None:
                ssh.terminate()
        threading.Thread(target=expire_transport, daemon=True).start()
        def drain_errors():
            while True:
                chunk = ssh.stderr.read(1024)
                if not chunk:
                    break
                stderr_tail.extend(chunk)
                del stderr_tail[:-2048]
        threading.Thread(target=drain_errors, daemon=True).start()
        deadline = time.monotonic() + 20
        while not core.port_open(upstream):
            if stop.wait(.1):
                if expired.is_set():
                    raise ReserveError("ACCESS_EXPIRED")
                return 0
            if ssh.poll() is not None or time.monotonic() > deadline:
                raise ReserveError(ssh_failure(bytes(stderr_tail)))
        gateway = Gateway(upstream)
        threading.Thread(target=gateway.serve, daemon=True).start()
        # Never emit readiness just because a listener opened: payload(gateway.port) must pass.
        probe = _Probe(payload, gateway.port)
        while not probe.finished():
            if stop.wait(.05):
                break
        if stop.is_set():
            if expired.is_set():
                raise ReserveError("ACCESS_EXPIRED")
            return 0
        if time.time() >= p["expiresAt"]:
            raise ReserveError("ACCESS_EXPIRED")
        adapter = TelegramWebAdapter(0, gateway.port, ("web.telegram.org",))
        threading.Thread(target=adapter.serve, daemon=True).start()
        if stop.is_set():
            if expired.is_set():
                raise ReserveError("ACCESS_EXPIRED")
            return 0
        emit("SOCKS %d" % gateway.port)
        emit("EXPIRES %d" % p["expiresAt"])
        emit("READY %d" % adapter.port)
        emit("PAC " + base64.b64encode(web_pac(adapter.port).encode()).decode())
        last_probe = time.monotonic()
        probe = None  # at most one periodic probe in flight
        while not stop.wait(.5):
            if time.time() >= p["expiresAt"]:
                raise ReserveError("ACCESS_EXPIRED")
            if ssh.poll() is not None or not core.port_open(upstream):
                raise ReserveError(ssh_failure(bytes(stderr_tail)))
            if probe is not None and probe.finished():
                probe = None
                last_probe = time.monotonic()
            if probe is None and time.monotonic() - last_probe >= PROBE_INTERVAL:
                probe = _Probe(payload, gateway.port)
        if expired.is_set():
            raise ReserveError("ACCESS_EXPIRED")
        return 0
    except ReserveError as e:
        emit("ERROR " + str(e)); emit("ROUTE_DOWN"); return 1
    except (OSError, ValueError, ssl.SSLError, http.client.HTTPException):
        emit("ERROR PAYLOAD_FAILED"); emit("ROUTE_DOWN"); return 1
    finally:
        expiry_cancelled.set()
        for server in (adapter, gateway):
            if server:
                server.close()
        if ssh is not None and ssh.poll() is None:
            ssh.terminate()
            try:
                ssh.wait(3)
            except subprocess.TimeoutExpired:
                ssh.kill(); ssh.wait()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--profile", default=str(DEFAULT_PROFILE))
    args = ap.parse_args()
    stop = threading.Event()
    for sig in (signal.SIGTERM, signal.SIGINT, signal.SIGHUP):
        signal.signal(sig, lambda *_: stop.set())
    def stdin_closed():
        try:
            while os.read(0, 1024):
                pass
        except OSError:
            pass
        stop.set()
    threading.Thread(target=stdin_closed, daemon=True).start()
    return run(args.profile, stop)


if __name__ == "__main__":
    sys.exit(main())
