"""Sphinx core: supervises `ssh -D` (loopback SOCKS) and serves a loopback-only,
allowlisted HTTP CONNECT adapter on top of it.

Protocol with the parent (Sphinx.app) on stdout, one line per event:
  READY <http_port>      adapter listening, SOCKS route confirmed
  SITES <d1,d2,...>      the exact domain allowlist the adapter enforces (same list as the PAC)
  PAC <base64>           PAC script for the isolated browser profile
  ERROR <code>           fatal, process exits (PIN_MISSING, PORT_IN_USE, ROUTE_FAILED, SITES_INVALID)
  ROUTE_DOWN             ssh/SOCKS gone; adapter closed; process exits
Closing stdin or SIGTERM performs a clean shutdown (ssh is terminated).

Site selection: --preset claude|chatgpt and --site <domain> (repeatable). With neither, both presets
are used (legacy behaviour, e.g. for scripts/sphinx-run.sh). Every domain is re-validated here.

Helpers for the GUI (no route involved):
  --check-site <text>    prints the normalized HTTPS domain, or "INVALID <reason>" (exit 1)
  --check-update         one bounded HTTPS GET of --feed-url; prints one JSON line; never installs

Nothing is written to disk. Host names are never logged.
"""
import argparse
import base64
import json
import os
import re
import select
import signal
import socket
import ssl
import subprocess
import sys
import threading
import time
import urllib.error
import urllib.request

PRESETS = {
    "claude": ("claude.ai", "anthropic.com", "claudeusercontent.com"),
    "chatgpt": ("chatgpt.com", "openai.com", "oaistatic.com", "oaiusercontent.com"),
}
DEFAULT_PRESETS = ("claude", "chatgpt")
ALLOWED_SUFFIXES = PRESETS["claude"] + PRESETS["chatgpt"]   # legacy default allowlist
MAX_CUSTOM_SITES = 12
MAX_SITE_INPUT = 2048
# TLDs that never name a public HTTPS site.
_RESERVED_TLDS = frozenset((
    "localhost", "local", "internal", "test", "invalid", "example", "onion", "arpa",
    "home", "lan", "corp", "intranet", "private", "localdomain",
))
# Registry-style suffixes: adding one would route every unrelated site under it.
_SHARED_SUFFIXES = frozenset((
    "co.uk", "org.uk", "ac.uk", "gov.uk", "me.uk", "com.au", "net.au", "org.au", "co.nz",
    "co.jp", "ne.jp", "or.jp", "co.kr", "com.br", "com.cn", "com.tr", "com.ua", "com.ru",
    "msk.ru", "spb.ru", "co.in", "co.za", "com.mx", "com.ar", "com.sg", "com.hk", "com.tw",
    "github.io", "gitlab.io", "pages.dev", "workers.dev", "vercel.app", "netlify.app",
    "herokuapp.com", "appspot.com", "web.app", "firebaseapp.com", "blogspot.com",
    "cloudfront.net", "amazonaws.com", "azurewebsites.net", "duckdns.org", "ngrok.io",
))
ALLOWED_PORT = 443
DEFAULT_HTTP_PORT = 18443
MAX_CLIENTS = 256
_LABEL = re.compile(r"^[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?$")


def normalize_host(host):
    host = host.strip().lower()
    if host.endswith("."):
        host = host[:-1]
    if not host or len(host) > 253:
        return None
    labels = host.split(".")
    if len(labels) < 2 or not all(_LABEL.match(l) for l in labels):
        return None          # also rejects IPv6 literals / odd chars
    if labels[-1].isdigit():
        return None          # IPv4 literal
    return host


def host_allowed(host, domains=ALLOWED_SUFFIXES):
    h = normalize_host(host)
    if h is None:
        return None
    for d in domains:
        if h == d or h.endswith("." + d):
            return h
    return None


class SiteError(ValueError):
    """Reason codes: EMPTY, TOO_LONG, SCHEME, USERINFO, PORT, HOST, IP, NOT_ASCII, RESERVED, SHARED."""


def parse_site(text):
    """Strictly turn user input (`example.com`, `https://example.com/path`) into a bare
    public DNS name that the adapter and PAC can match. HTTPS on port 443 only."""
    if not isinstance(text, str):
        raise SiteError("EMPTY")
    value = text.strip()
    if not value:
        raise SiteError("EMPTY")
    if len(value) > MAX_SITE_INPUT:
        raise SiteError("TOO_LONG")
    if any(ord(ch) > 126 for ch in value):
        raise SiteError("NOT_ASCII")         # IDNs must be entered as punycode (xn--)
    if any(ord(ch) <= 32 for ch in value) or "\\" in value:
        raise SiteError("HOST")
    if "://" in value:
        scheme, value = value.split("://", 1)
        if scheme.lower() != "https":
            raise SiteError("SCHEME")
    elif re.match(r"^[A-Za-z][A-Za-z0-9+.-]*:(?!\d+(?:[/?#]|$))", value):
        raise SiteError("SCHEME")            # mailto:, javascript:, http:x ...
    authority = re.split(r"[/?#]", value, 1)[0]
    if "@" in authority:
        raise SiteError("USERINFO")
    if "[" in authority or "]" in authority:
        raise SiteError("IP")
    if ":" in authority:
        authority, port = authority.split(":", 1)
        if port != "443":
            raise SiteError("PORT")
    host = authority.lower()
    if host.endswith("."):
        host = host[:-1]
    if re.match(r"^[0-9.]+$", host) or re.match(r"^0x", host):
        raise SiteError("IP")
    h = normalize_host(host)
    if h is None:
        raise SiteError("HOST")
    tld = h.rsplit(".", 1)[1]
    if not (re.match(r"^[a-z]{2,63}$", tld) or re.match(r"^xn--[a-z0-9-]{1,59}$", tld)):
        raise SiteError("HOST")
    if tld in _RESERVED_TLDS:
        raise SiteError("RESERVED")
    if h in _SHARED_SUFFIXES:
        raise SiteError("SHARED")
    return h


def build_allowlist(presets, sites):
    """Ordered, de-duplicated domain allowlist. Raises SiteError on anything unsafe or empty."""
    out = []
    for name in presets:
        if name not in PRESETS:
            raise SiteError("PRESET")
        out.extend(PRESETS[name])
    if len(sites) > MAX_CUSTOM_SITES:
        raise SiteError("TOO_MANY")
    for raw in sites:
        if parse_site(raw) != raw:      # the parent must pass already-normalized names
            raise SiteError("HOST")
        out.append(raw)
    seen, result = set(), []
    for d in out:
        if d not in seen:
            seen.add(d)
            result.append(d)
    if not result:
        raise SiteError("EMPTY")
    return tuple(result)


# --- update check: one bounded HTTPS GET, result is informational only -------------------
FEED_MAX_BYTES = 65536
FEED_TIMEOUT = 8
_VERSION = re.compile(r"^\d{1,4}(?:\.\d{1,4}){1,3}$")


class _NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *a, **k):
        return None                      # a fixed feed URL must answer directly


def _version_tuple(v):
    return tuple(int(x) for x in v.split("."))


def evaluate_feed(status, body, current):
    """Map an HTTP status and body to {"state": ...}. Only a version string is ever taken
    from the response; links or files inside it are ignored."""
    if status == 404:
        return {"state": "unpublished"}
    if status != 200 or body is None:
        return {"state": "unavailable"}
    try:
        doc = json.loads(body.decode("utf-8"))
    except (ValueError, UnicodeDecodeError):
        return {"state": "invalid"}
    if not isinstance(doc, dict):
        return {"state": "invalid"}
    entry = doc.get("macos") if isinstance(doc.get("macos"), dict) else doc
    version = entry.get("version")
    if not isinstance(version, str) or not _VERSION.match(version):
        return {"state": "invalid"}
    if not _VERSION.match(current):
        return {"state": "invalid"}
    if _version_tuple(version) > _version_tuple(current):
        return {"state": "available", "version": version}
    return {"state": "current", "version": version}


def check_update(url, current, cafile=None):
    if not url.startswith("https://"):
        return {"state": "unavailable"}
    ctx = ssl.create_default_context(cafile=cafile)
    opener = urllib.request.build_opener(
        urllib.request.ProxyHandler({}), _NoRedirect(), urllib.request.HTTPSHandler(context=ctx))
    req = urllib.request.Request(url, headers={"Accept": "application/json",
                                               "Accept-Encoding": "identity",
                                               "User-Agent": "Sphinx-macOS"})
    try:
        with opener.open(req, timeout=FEED_TIMEOUT) as resp:
            if resp.headers.get("Content-Encoding", "identity").lower() != "identity":
                return {"state": "invalid"}
            body = resp.read(FEED_MAX_BYTES + 1)
            if len(body) > FEED_MAX_BYTES:
                return {"state": "invalid"}
            return evaluate_feed(resp.status, body, current)
    except urllib.error.HTTPError as e:
        return evaluate_feed(e.code, None, current)
    except (OSError, ValueError, ssl.SSLError):
        return {"state": "unavailable"}


def pac_script(http_port, allowlist=ALLOWED_SUFFIXES):
    domains = ", ".join('"%s"' % d for d in allowlist)
    return (
        "function FindProxyForURL(url, host) {\n"
        "  var h = String(host).toLowerCase();\n"
        "  if (h.charAt(h.length - 1) === \".\") h = h.substring(0, h.length - 1);\n"
        "  var d = [%s];\n"
        "  for (var i = 0; i < d.length; i++) {\n"
        "    var s = \".\" + d[i];\n"
        "    if (h === d[i] || (h.length > s.length && h.substring(h.length - s.length) === s))\n"
        "      return \"PROXY 127.0.0.1:%d\";\n"
        "  }\n"
        "  return \"DIRECT\";\n"
        "}\n" % (domains, http_port)
    )


def ssh_command(ssh_bin, host_alias, socks_port, known_hosts):
    # OpenSSH parses -o values as config text even when passed as one argv item.
    quoted_pin = known_hosts.replace("\\", "\\\\").replace('"', '\\"')
    return [
        ssh_bin, "-N", "-T", "-a", "-x",
        "-D", "127.0.0.1:%d" % socks_port,
        "-o", "BatchMode=yes",
        "-o", "ExitOnForwardFailure=yes",
        "-o", "ForwardAgent=no",
        "-o", "ForwardX11=no",
        "-o", "GatewayPorts=no",
        "-o", "PermitLocalCommand=no",
        "-o", "ControlMaster=no",
        "-o", "ControlPath=none",
        "-o", "StrictHostKeyChecking=yes",
        "-o", 'UserKnownHostsFile="%s"' % quoted_pin,
        "-o", "GlobalKnownHostsFile=/dev/null",
        "-o", "UpdateHostKeys=no",
        "-o", "ConnectTimeout=15",
        "-o", "ServerAliveInterval=15",
        "-o", "ServerAliveCountMax=3",
        "-o", "LogLevel=ERROR",
        host_alias,
    ]


def emit(line):
    sys.stdout.write(line + "\n")
    sys.stdout.flush()


def free_loopback_port():
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.bind(("127.0.0.1", 0))
    p = s.getsockname()[1]
    s.close()
    return p


def port_open(port):
    try:
        socket.create_connection(("127.0.0.1", port), timeout=0.5).close()
        return True
    except OSError:
        return False


def socks5_connect(socks_port, host, port):
    """Open a tunnel via the loopback SOCKS5 (remote side resolves DNS)."""
    s = socket.create_connection(("127.0.0.1", socks_port), timeout=10)
    try:
        s.sendall(b"\x05\x01\x00")
        if _recv_exact(s, 2) != b"\x05\x00":
            raise OSError("socks auth")
        hb = host.encode("ascii")
        s.sendall(b"\x05\x01\x00\x03" + bytes([len(hb)]) + hb + port.to_bytes(2, "big"))
        head = _recv_exact(s, 4)
        if head[1] != 0:
            raise OSError("socks refused")
        atyp = head[3]
        n = {1: 4, 4: 16}.get(atyp)
        if n is None:
            n = _recv_exact(s, 1)[0]
        _recv_exact(s, n + 2)
        s.settimeout(None)
        return s
    except Exception:
        s.close()
        raise


def _recv_exact(s, n):
    buf = b""
    while len(buf) < n:
        chunk = s.recv(n - len(buf))
        if not chunk:
            raise OSError("eof")
        buf += chunk
    return buf


def _reply(c, status, text):
    try:
        c.sendall(("HTTP/1.1 %d %s\r\nContent-Length: 0\r\nConnection: close\r\n\r\n"
                   % (status, text)).encode())
    except OSError:
        pass


def _relay(a, b):
    socks = [a, b]
    try:
        while True:
            r, _, x = select.select(socks, [], socks, 300)
            if x or not r:
                return
            for s in r:
                data = s.recv(65536)
                if not data:
                    return
                (b if s is a else a).sendall(data)
    except OSError:
        return


class Adapter(object):
    def __init__(self, http_port, socks_port, allowlist=ALLOWED_SUFFIXES):
        self.socks_port = socks_port
        self.allowlist = tuple(allowlist)
        self.sem = threading.BoundedSemaphore(MAX_CLIENTS)
        self.lsock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.lsock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.lsock.bind(("127.0.0.1", http_port))   # loopback only
        self.lsock.listen(64)
        self.port = self.lsock.getsockname()[1]
        self.closed = False

    def serve(self):
        while not self.closed:
            try:
                c, _ = self.lsock.accept()
            except OSError:
                return
            if not self.sem.acquire(blocking=False):
                _reply(c, 503, "Busy")
                c.close()
                continue
            threading.Thread(target=self._handle, args=(c,), daemon=True).start()

    def close(self):
        self.closed = True
        try:
            self.lsock.close()
        except OSError:
            pass

    def _handle(self, c):
        up = None
        try:
            c.settimeout(10)
            head = b""
            while b"\r\n\r\n" not in head:
                chunk = c.recv(4096)
                if not chunk:
                    return
                head += chunk
                if len(head) > 8192:
                    return _reply(c, 431, "Too Large")
            line = head.split(b"\r\n", 1)[0].decode("latin-1")
            parts = line.split(" ")
            if len(parts) != 3 or parts[0] != "CONNECT":
                return _reply(c, 405, "Method Not Allowed")
            hostport = parts[1]
            m = re.match(r"^([^:\[\]]+):(\d{1,5})$", hostport)
            if not m or int(m.group(2)) != ALLOWED_PORT:
                return _reply(c, 403, "Forbidden")
            host = host_allowed(m.group(1), self.allowlist)
            if host is None:
                return _reply(c, 403, "Forbidden")
            if self.closed:
                return _reply(c, 502, "Route Down")
            try:
                up = socks5_connect(self.socks_port, host, ALLOWED_PORT)
            except (OSError, IndexError):
                return _reply(c, 502, "Route Down")   # fail closed, never DIRECT
            c.sendall(b"HTTP/1.1 200 Connection Established\r\n\r\n")
            rest = head.split(b"\r\n\r\n", 1)[1]
            if rest:
                up.sendall(rest)
            c.settimeout(None)
            _relay(c, up)
        except OSError:
            pass
        finally:
            for s in (c, up):
                if s is not None:
                    try:
                        s.close()
                    except OSError:
                        pass
            self.sem.release()


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("--http-port", type=int, default=DEFAULT_HTTP_PORT)
    ap.add_argument("--ssh-host", default="hestia")
    ap.add_argument("--ssh-bin", default="/usr/bin/ssh")
    ap.add_argument("--known-hosts", default=os.path.expanduser(
        "~/Library/Application Support/Sphinx/known_hosts"))
    ap.add_argument("--socks-port", type=int, default=0,
                    help="use an existing loopback SOCKS5 instead of spawning ssh (tests)")
    ap.add_argument("--print-pac", action="store_true")
    ap.add_argument("--preset", action="append", default=[], choices=sorted(PRESETS))
    ap.add_argument("--site", action="append", default=[])
    ap.add_argument("--check-site", metavar="TEXT")
    ap.add_argument("--check-update", action="store_true")
    ap.add_argument("--feed-url", default="")
    ap.add_argument("--current-version", default="")
    ap.add_argument("--cafile", help=argparse.SUPPRESS)   # tests only: local TLS root
    a = ap.parse_args(argv)

    if a.check_site is not None:
        try:
            emit(parse_site(a.check_site))
            return 0
        except SiteError as e:
            emit("INVALID %s" % e)
            return 1
    if a.check_update:
        emit(json.dumps(check_update(a.feed_url, a.current_version, a.cafile), sort_keys=True))
        return 0

    presets = a.preset if (a.preset or a.site) else list(DEFAULT_PRESETS)
    try:
        allowlist = build_allowlist(presets, a.site)
    except SiteError:
        emit("ERROR SITES_INVALID")      # fail closed before anything starts
        return 6

    if a.print_pac:
        sys.stdout.write(pac_script(a.http_port, allowlist))
        return 0

    stop = threading.Event()
    signal.signal(signal.SIGTERM, lambda *_: stop.set())
    signal.signal(signal.SIGINT, lambda *_: stop.set())
    signal.signal(signal.SIGHUP, lambda *_: stop.set())

    def watch_stdin():
        try:
            while os.read(0, 1024):
                pass
        except OSError:
            pass
        stop.set()
    threading.Thread(target=watch_stdin, daemon=True).start()

    ssh = None
    socks_port = a.socks_port
    if not socks_port:
        if not (os.path.isfile(a.known_hosts) and os.path.getsize(a.known_hosts) > 0):
            emit("ERROR PIN_MISSING")
            return 2
        socks_port = free_loopback_port()
        ssh = subprocess.Popen(
            ssh_command(a.ssh_bin, a.ssh_host, socks_port, a.known_hosts),
            stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL, close_fds=True)

    def route_alive():
        return (ssh is None or ssh.poll() is None) and port_open(socks_port)

    code = 0
    adapter = None
    try:
        deadline = time.time() + 20
        while not route_alive():
            if stop.is_set():
                return 0
            if (ssh is not None and ssh.poll() is not None) or time.time() > deadline:
                emit("ERROR ROUTE_FAILED")
                return 3
            time.sleep(0.2)
        try:
            adapter = Adapter(a.http_port, socks_port, allowlist)
        except OSError:
            emit("ERROR PORT_IN_USE")
            return 4
        threading.Thread(target=adapter.serve, daemon=True).start()
        emit("READY %d" % adapter.port)
        emit("SITES " + ",".join(adapter.allowlist))
        emit("PAC " + base64.b64encode(pac_script(adapter.port, adapter.allowlist).encode()).decode())
        while not stop.wait(1.0):
            if not route_alive():
                adapter.close()
                emit("ROUTE_DOWN")
                code = 5
                break
    finally:
        if adapter is not None:
            adapter.close()
        if ssh is not None and ssh.poll() is None:
            ssh.terminate()
            try:
                ssh.wait(3)
            except subprocess.TimeoutExpired:
                ssh.kill()
                ssh.wait()
    return code


if __name__ == "__main__":
    sys.exit(main())
